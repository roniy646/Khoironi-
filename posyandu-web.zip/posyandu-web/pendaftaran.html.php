<?php
include 'koneksi.php';

$pesanSukses = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil semua data dari form
    $nama           = $_POST['nama'];
    $tanggal_lahir  = $_POST['tanggal_lahir'];
    $orang_tua      = $_POST['orang_tua'];
    $alamat         = $_POST['alamat'];
    $jenis_kelamin  = $_POST['jenis_kelamin'];
    $berat_badan    = $_POST['berat_badan'];
    $tinggi_badan   = $_POST['tinggi_badan'];
    $imt            = $_POST['imt'];

    $sql = "INSERT INTO balita (nama, tanggal_lahir, orang_tua, alamat, jenis_kelamin, berat_badan, tinggi_badan, imt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ssssssss", $nama, $tanggal_lahir, $orang_tua, $alamat, $jenis_kelamin, $berat_badan, $tinggi_badan, $imt);

    if ($stmt->execute()) {
        $pesanSukses = true;
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Pendaftaran Balita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/1.css">
</head>

<body class="app-body">
    <div class="app-root">
        <nav class="app-navbar">
            <img src="img/logo.png" alt="Logo Posyandu" class="app-logo" />
            <a href="index.html.php">Beranda</a>
            <a href="pendaftaran.html.php" class="active">Pendaftaran Balita</a>
            <a href="data-balita.html.php">Data Balita</a>
            <a href="transaksi.html.php">Transaksi</a>
            <a href="data-transaksi.html.php">Data Transaksi</a>
        </nav>

        <div class="app-main-content">
            <div class="container app-container">
                <section class="app-section">
                    <h2 class="text-center mb-4">Pendaftaran Balita</h2>
                    <form id="formPendaftaran" method="POST" action="" class="mt-4">
                        <div class="card p-4 shadow-sm">
                            <div class="mb-3">
                                <label for="nama" class="form-label">Nama Balita</label>
                                <input type="text" class="form-control" id="nama" name="nama" required>
                            </div>

                            <div class="mb-3">
                                <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                            </div>
                            <div class="mb-3">
                                <label for="orang_tua" class="form-label">Nama Orang Tua</label>
                                <input type="text" class="form-control" id="orang_tua" name="orang_tua" required>
                            </div>

                            <div class="mb-3">
                                <label for="alamat" class="form-label">Alamat</label>
                                <textarea class="form-control" id="alamat" name="alamat" rows="2" required></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                                <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                                    <option value="">Pilih Jenis Kelamin</option>
                                    <option value="Laki-laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="berat" class="form-label">Berat Badan (kg)</label>
                                <input type="number" class="form-control" id="berat" name="berat_badan" min="1" step="0.1" onchange="hitungIMT();" required>
                            </div>

                            <div class="mb-3">
                                <label for="tinggi" class="form-label">Tinggi Badan (cm)</label>
                                <input type="number" class="form-control" id="tinggi" name="tinggi_badan" min="30" step="0.1" onchange="hitungIMT();" required>
                            </div>

                            <div class="mb-3">
                                <label for="imt" class="form-label">IMT</label>
                                <input type="text" class="form-control" id="imt" name="imt" readonly>
                            </div>

                            <div class="text-start">
                                <button type="submit" class="btn btn-primary app-btn-daftar">Daftar</button>
                            </div>
                        </div>
                    </form>

                    <?php if ($pesanSukses): ?>
                        <div class="alert alert-success text-center mt-4" role="alert">
                            Data balita berhasil didaftarkan!
                        </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </div>

    <script>
        function hitungIMT() {
            const berat = parseFloat(document.getElementById("berat").value) || 0;
            const tinggi = parseFloat(document.getElementById("tinggi").value) / 100 || 0; // Ubah cm ke meter
            if (berat > 0 && tinggi > 0) {
                const imt = (berat / (tinggi * tinggi)).toFixed(2); // Rumus IMT
                document.getElementById("imt").value = imt;
            } else {
                document.getElementById("imt").value = '';
            }
        }
    </script>
</body>

</html>