<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_balita = $_POST["id_balita"];
    $jenis_transaksi = $_POST["jenis_transaksi"];
    $tanggal = $_POST["tanggal_transaksi"];
    $jumlah = $_POST["jumlah"];
    $keterangan = $_POST["keterangan"];

    $sql_insert = "INSERT INTO transaksi (id_balita, jenis_transaksi, jumlah, tanggal, keterangan) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql_insert);

    $stmt->bind_param("isiss", $id_balita, $jenis_transaksi, $jumlah, $tanggal, $keterangan);

    $stmt->execute();
    $stmt->close();

    echo '<script>document.addEventListener("DOMContentLoaded",function(){document.getElementById("pesanTransaksiSukses").style.display="block";});</script>';
}

$balita = [];
$sqlBalita = "SELECT id, nama FROM balita ORDER BY nama ASC";
$resultBalita = $conn->query($sqlBalita);
while ($row = $resultBalita->fetch_assoc()) {
    $balita[] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Transaksi Posyandu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/1.css">
</head>

<body class="app-body">
    <div class="app-root">
        <nav class="app-navbar">
            <img src="img/logo.png" alt="Logo Posyandu" class="app-logo" />
            <a href="index.html.php">Beranda</a>
            <a href="pendaftaran.html.php">Pendaftaran Balita</a>
            <a href="data-balita.html.php">Data Balita</a>
            <a href="transaksi.html.php" class="active">Transaksi</a>
            <a href="data-transaksi.html.php">Data Transaksi</a>
        </nav>

        <div class="app-main-content">
            <div class="container app-container py-4">
                <section class="app-section">
                    <h2 class="text-center mb-4">Transaksi</h2>
                    <p class="transaksi-desc text-center mb-4">
                        Catat transaksi pembayaran iuran, pembelian makanan tambahan, dan keuangan lainnya di Posyandu.
                    </p>

                    <form id="formTransaksi" method="POST" action="" class="mb-4">
                        <div class="card p-4 shadow-sm">
                            <div class="mb-3">
                                <label for="id_balita" class="form-label">Nama Balita</label>
                                <select id="id_balita" name="id_balita" class="form-select" required>
                                    <option value="">Pilih Balita</option>
                                    <?php foreach ($balita as $b): ?>
                                        <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['nama']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="jenis_transaksi" class="form-label">Jenis Transaksi</label>
                                <select id="jenis_transaksi" name="jenis_transaksi" class="form-select" required>
                                    <option value="">Pilih Jenis Transaksi</option>
                                    <option value="Iuran Bulanan">Iuran Bulanan</option>
                                    <option value="Pembelian PMT">Pembelian PMT</option>
                                    <option value="Imunisasi">Imunisasi</option>
                                    <option value="Pemeriksaan Kesehatan">Pemeriksaan Kesehatan</option>
                                    <option value="Penimbangan Balita">Penimbangan Balita</option>
                                    <option value="Lainnya">Lainnya</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="tanggal_transaksi" class="form-label">Tanggal</label>
                                <input type="date" id="tanggal_transaksi" name="tanggal_transaksi" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="jumlah" class="form-label">Jumlah</label>
                                <input type="number" id="jumlah" name="jumlah" class="form-control" min="0" step="1" required>
                            </div>
                            <div class="mb-3">
                                <label for="keterangan" class="form-label">Keterangan</label>
                                <input type="text" id="keterangan" name="keterangan" class="form-control" placeholder="Opsional">
                            </div>
                            <div class="text-start">
                                <button type="submit" class="btn btn-primary app-btn-daftar">Catat</button>
                            </div>
                        </div>
                    </form>
                    <div id="pesanTransaksiSukses" class="alert alert-success mt-4 text-center app-pesan-sukses" style="display:none;">
                        <p class="mb-0">Transaksi berhasil dicatat!</p>
                    </div>
                </section>
            </div>
        </div>
    </div>
</body>

</html>