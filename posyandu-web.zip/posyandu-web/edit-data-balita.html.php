<?php
include "koneksi.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM balita WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $balita = $result->fetch_assoc();

    if (!$balita) {
        echo "Data tidak ditemukan!";
        exit;
    }
} else {
    echo "ID tidak ditemukan!";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $tanggal_lahir = $_POST["tanggal_lahir"];
    $orang_tua = $_POST["orang_tua"];
    $alamat = $_POST["alamat"];
    $jenis_kelamin = $_POST["jenis_kelamin"];
    $berat_badan = $_POST["berat_badan"];
    $tinggi_badan = $_POST["tinggi_badan"];
    $imt = round($berat_badan / pow($tinggi_badan / 100, 2), 2); // hitung ulang IMT

    $update = "UPDATE balita SET nama=?, tanggal_lahir=?, orang_tua=?, alamat=?, jenis_kelamin=?, berat_badan=?, tinggi_badan=?, imt=? WHERE id=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("ssssssddi", $nama, $tanggal_lahir, $orang_tua, $alamat, $jenis_kelamin, $berat_badan, $tinggi_badan, $imt, $id);
    if ($stmt->execute()) {
        header("Location: data-balita.html.php");
        exit;
    } else {
        echo "Gagal memperbarui data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Balita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <div class="container">
        <h2>Edit Data Balita</h2>
        <form method="POST">
            <div class="mb-3">
                <label>Nama Balita</label>
                <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($balita['nama']) ?>" required>
            </div>
            <div class="mb-3">
                <label>Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir" class="form-control" value="<?= htmlspecialchars($balita['tanggal_lahir']) ?>" required>
            </div>
            <div class="mb-3">
                <label>Nama Orang Tua</label>
                <input type="text" name="orang_tua" class="form-control" value="<?= htmlspecialchars($balita['orang_tua']) ?>" required>
            </div>
            <div class="mb-3">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control" value="<?= htmlspecialchars($balita['alamat']) ?>" required>
            </div>
            <div class="mb-3">
                <label>Jenis Kelamin</label>
                <select name="jenis_kelamin" class="form-control" required>
                    <option value="Laki-laki" <?= $balita['jenis_kelamin'] == 'Laki-laki' ? 'selected' : '' ?>>Laki-laki</option>
                    <option value="Perempuan" <?= $balita['jenis_kelamin'] == 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Berat Badan (kg)</label>
                <input type="number" name="berat_badan" step="0.1" class="form-control" value="<?= htmlspecialchars($balita['berat_badan']) ?>" required>
            </div>
            <div class="mb-3">
                <label>Tinggi Badan (cm)</label>
                <input type="number" name="tinggi_badan" step="0.1" class="form-control" value="<?= htmlspecialchars($balita['tinggi_badan']) ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="data-balita.html.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
