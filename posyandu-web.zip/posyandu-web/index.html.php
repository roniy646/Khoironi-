<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda Posyandu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/1.css">    
</head>
<body class="app-body">
    <div class="app-root">
        <nav class="app-navbar">
            <img src="img/logo.png" alt="Logo Posyandu1" class="app-logo" />
            <a href="index.html.php" class="active">Beranda</a>
            <a href="pendaftaran.html.php">Pendaftaran Balita</a>
            <a href="data-balita.html.php">Data Balita</a>
            <a href="transaksi.html.php">Transaksi</a>
            <a href="data-transaksi.html.php">Data Transaksi</a>
        </nav>
        <div class="app-main-content">
            <div class="container app-container py-4">
                <h1 class="text-center mb-4">Selamat Datang di Posyandu Ceria</h1>
                <div class="text-center mb-4">
                    <img src="img/logo1.png" alt="Logo Posyandu" style="max-width: 220px;" class="app-logo">
                </div>
                <section class="app-section welcome mb-4">
                    <h2 class="mb-3">Pelayanan Kesehatan Ibu dan Anak</h2>
                    <p class="lead">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis perferendis repellat aliquid commodi sint, omnis quia ducimus officiis facere rem non explicabo, in recusandae dolorum aliquam earum error. Nulla, quaerat?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium illo deleniti consequatur, animi in possimus modi quisquam unde corporis, facere cupiditate nemo, corrupti tempora molestiae eos amet vero explicabo provident!
                    </p>
                </section>
                <footer class="app-footer mt-4">
                    &copy; 2025 Posyandu Ceria.
                </footer>
            </div>
        </div>
    </div>
</body>
</html>