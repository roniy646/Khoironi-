<?php
include "koneksi.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $check = $conn->query("SELECT id FROM balita WHERE id=$id");
    if ($check && $check->num_rows > 0) {
        $sql = "DELETE FROM balita WHERE id=$id";
        if ($conn->query($sql) === TRUE) {
            header("Location: data-balita.html.php?status=deleted");
            exit;
        } else {
            echo "<script>alert('Gagal menghapus data!'); window.location='data-balita.html.php';</script>";
            exit;
        }
    } else {
        echo "<script>alert('Data tidak ditemukan!'); window.location='data-balita.html.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID tidak valid!'); window.location='data-balita.html.php';</script>";
    exit;
}
?>                                                                                                              